//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VBDecMod.rc
//
#define IDD_VBD_MODULE                  101
#define IDE_OUTPUT                      1000
#define IDC_VBD_TREE                    1001
#define IDL_LOG                         1002
#define IDC_EXIT                        1003
#define IDG_INFO                        -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
